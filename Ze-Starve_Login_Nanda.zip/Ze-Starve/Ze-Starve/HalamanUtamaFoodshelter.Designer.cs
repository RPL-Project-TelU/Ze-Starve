﻿
namespace Ze_Starve
{
    partial class HalamanUtamaFoodshelter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabHalamanFoodshelter = new System.Windows.Forms.TabControl();
            this.PageFoodshelter = new System.Windows.Forms.TabPage();
            this.BtnAktivitasFoodshelter = new System.Windows.Forms.Button();
            this.BtnTambahAktivitas = new System.Windows.Forms.Button();
            this.LblAktivitasFoodshelter = new System.Windows.Forms.Label();
            this.LblTambahAktivitas = new System.Windows.Forms.Label();
            this.BtnStatistik = new System.Windows.Forms.Button();
            this.LblStatistik = new System.Windows.Forms.Label();
            this.PageNotifikasi = new System.Windows.Forms.TabPage();
            this.PageAkun = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnEditAkun = new System.Windows.Forms.Button();
            this.LblBantuan = new System.Windows.Forms.Label();
            this.LblEditAkun = new System.Windows.Forms.Label();
            this.TabHalamanFoodshelter.SuspendLayout();
            this.PageFoodshelter.SuspendLayout();
            this.PageAkun.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabHalamanFoodshelter
            // 
            this.TabHalamanFoodshelter.Controls.Add(this.PageFoodshelter);
            this.TabHalamanFoodshelter.Controls.Add(this.PageNotifikasi);
            this.TabHalamanFoodshelter.Controls.Add(this.PageAkun);
            this.TabHalamanFoodshelter.Location = new System.Drawing.Point(2, 2);
            this.TabHalamanFoodshelter.Name = "TabHalamanFoodshelter";
            this.TabHalamanFoodshelter.SelectedIndex = 0;
            this.TabHalamanFoodshelter.Size = new System.Drawing.Size(868, 453);
            this.TabHalamanFoodshelter.TabIndex = 3;
            // 
            // PageFoodshelter
            // 
            this.PageFoodshelter.Controls.Add(this.BtnAktivitasFoodshelter);
            this.PageFoodshelter.Controls.Add(this.BtnTambahAktivitas);
            this.PageFoodshelter.Controls.Add(this.LblAktivitasFoodshelter);
            this.PageFoodshelter.Controls.Add(this.LblTambahAktivitas);
            this.PageFoodshelter.Controls.Add(this.BtnStatistik);
            this.PageFoodshelter.Controls.Add(this.LblStatistik);
            this.PageFoodshelter.Location = new System.Drawing.Point(4, 25);
            this.PageFoodshelter.Name = "PageFoodshelter";
            this.PageFoodshelter.Padding = new System.Windows.Forms.Padding(3);
            this.PageFoodshelter.Size = new System.Drawing.Size(860, 424);
            this.PageFoodshelter.TabIndex = 0;
            this.PageFoodshelter.Text = "Foodshelter";
            this.PageFoodshelter.UseVisualStyleBackColor = true;
            // 
            // BtnAktivitasFoodshelter
            // 
            this.BtnAktivitasFoodshelter.BackgroundImage = global::Ze_Starve.Properties.Resources.logoZStarve01;
            this.BtnAktivitasFoodshelter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnAktivitasFoodshelter.Location = new System.Drawing.Point(416, 38);
            this.BtnAktivitasFoodshelter.Name = "BtnAktivitasFoodshelter";
            this.BtnAktivitasFoodshelter.Size = new System.Drawing.Size(130, 130);
            this.BtnAktivitasFoodshelter.TabIndex = 19;
            this.BtnAktivitasFoodshelter.UseVisualStyleBackColor = true;
            this.BtnAktivitasFoodshelter.Click += new System.EventHandler(this.BtnAktivitasFoodshelter_Click);
            // 
            // BtnTambahAktivitas
            // 
            this.BtnTambahAktivitas.BackgroundImage = global::Ze_Starve.Properties.Resources.Icon_Tambah;
            this.BtnTambahAktivitas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnTambahAktivitas.Location = new System.Drawing.Point(46, 38);
            this.BtnTambahAktivitas.Name = "BtnTambahAktivitas";
            this.BtnTambahAktivitas.Size = new System.Drawing.Size(130, 130);
            this.BtnTambahAktivitas.TabIndex = 16;
            this.BtnTambahAktivitas.UseVisualStyleBackColor = true;
            this.BtnTambahAktivitas.Click += new System.EventHandler(this.BtnTambahAktivitas_Click);
            // 
            // LblAktivitasFoodshelter
            // 
            this.LblAktivitasFoodshelter.BackColor = System.Drawing.SystemColors.Control;
            this.LblAktivitasFoodshelter.Location = new System.Drawing.Point(416, 167);
            this.LblAktivitasFoodshelter.Name = "LblAktivitasFoodshelter";
            this.LblAktivitasFoodshelter.Size = new System.Drawing.Size(130, 45);
            this.LblAktivitasFoodshelter.TabIndex = 18;
            this.LblAktivitasFoodshelter.Text = "Aktivitas Foodshelter";
            this.LblAktivitasFoodshelter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTambahAktivitas
            // 
            this.LblTambahAktivitas.BackColor = System.Drawing.SystemColors.Control;
            this.LblTambahAktivitas.Location = new System.Drawing.Point(46, 167);
            this.LblTambahAktivitas.Name = "LblTambahAktivitas";
            this.LblTambahAktivitas.Size = new System.Drawing.Size(130, 30);
            this.LblTambahAktivitas.TabIndex = 14;
            this.LblTambahAktivitas.Text = "Tambah Aktivitas";
            this.LblTambahAktivitas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnStatistik
            // 
            this.BtnStatistik.BackgroundImage = global::Ze_Starve.Properties.Resources.Statistik;
            this.BtnStatistik.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnStatistik.Location = new System.Drawing.Point(232, 38);
            this.BtnStatistik.Name = "BtnStatistik";
            this.BtnStatistik.Size = new System.Drawing.Size(130, 130);
            this.BtnStatistik.TabIndex = 17;
            this.BtnStatistik.UseVisualStyleBackColor = true;
            // 
            // LblStatistik
            // 
            this.LblStatistik.BackColor = System.Drawing.SystemColors.Control;
            this.LblStatistik.Location = new System.Drawing.Point(232, 167);
            this.LblStatistik.Name = "LblStatistik";
            this.LblStatistik.Size = new System.Drawing.Size(130, 30);
            this.LblStatistik.TabIndex = 15;
            this.LblStatistik.Text = "Statistik";
            this.LblStatistik.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PageNotifikasi
            // 
            this.PageNotifikasi.Location = new System.Drawing.Point(4, 25);
            this.PageNotifikasi.Name = "PageNotifikasi";
            this.PageNotifikasi.Size = new System.Drawing.Size(860, 424);
            this.PageNotifikasi.TabIndex = 2;
            this.PageNotifikasi.Text = "Notifikasi";
            this.PageNotifikasi.UseVisualStyleBackColor = true;
            // 
            // PageAkun
            // 
            this.PageAkun.Controls.Add(this.button1);
            this.PageAkun.Controls.Add(this.BtnEditAkun);
            this.PageAkun.Controls.Add(this.LblBantuan);
            this.PageAkun.Controls.Add(this.LblEditAkun);
            this.PageAkun.Location = new System.Drawing.Point(4, 25);
            this.PageAkun.Name = "PageAkun";
            this.PageAkun.Padding = new System.Windows.Forms.Padding(3);
            this.PageAkun.Size = new System.Drawing.Size(860, 424);
            this.PageAkun.TabIndex = 1;
            this.PageAkun.Text = "Akun";
            this.PageAkun.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Ze_Starve.Properties.Resources.Statistik;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(232, 35);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 130);
            this.button1.TabIndex = 21;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // BtnEditAkun
            // 
            this.BtnEditAkun.BackgroundImage = global::Ze_Starve.Properties.Resources.Edit;
            this.BtnEditAkun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnEditAkun.Location = new System.Drawing.Point(47, 35);
            this.BtnEditAkun.Name = "BtnEditAkun";
            this.BtnEditAkun.Size = new System.Drawing.Size(130, 130);
            this.BtnEditAkun.TabIndex = 22;
            // 
            // LblBantuan
            // 
            this.LblBantuan.BackColor = System.Drawing.SystemColors.Control;
            this.LblBantuan.Location = new System.Drawing.Point(232, 168);
            this.LblBantuan.Name = "LblBantuan";
            this.LblBantuan.Size = new System.Drawing.Size(130, 30);
            this.LblBantuan.TabIndex = 19;
            this.LblBantuan.Text = "Pusat Bantuan";
            this.LblBantuan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblEditAkun
            // 
            this.LblEditAkun.BackColor = System.Drawing.SystemColors.Control;
            this.LblEditAkun.Location = new System.Drawing.Point(46, 168);
            this.LblEditAkun.Name = "LblEditAkun";
            this.LblEditAkun.Size = new System.Drawing.Size(130, 30);
            this.LblEditAkun.TabIndex = 18;
            this.LblEditAkun.Text = "Edit Akun";
            this.LblEditAkun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HalamanUtamaFoodshelter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 457);
            this.Controls.Add(this.TabHalamanFoodshelter);
            this.Name = "HalamanUtamaFoodshelter";
            this.Text = "Halaman Utama FoodShelter";
            this.TabHalamanFoodshelter.ResumeLayout(false);
            this.PageFoodshelter.ResumeLayout(false);
            this.PageAkun.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabHalamanFoodshelter;
        private System.Windows.Forms.TabPage PageFoodshelter;
        private System.Windows.Forms.Button BtnAktivitasFoodshelter;
        private System.Windows.Forms.Button BtnTambahAktivitas;
        private System.Windows.Forms.Label LblAktivitasFoodshelter;
        private System.Windows.Forms.Label LblTambahAktivitas;
        private System.Windows.Forms.Button BtnStatistik;
        private System.Windows.Forms.Label LblStatistik;
        private System.Windows.Forms.TabPage PageNotifikasi;
        private System.Windows.Forms.TabPage PageAkun;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BtnEditAkun;
        private System.Windows.Forms.Label LblBantuan;
        private System.Windows.Forms.Label LblEditAkun;
    }
}