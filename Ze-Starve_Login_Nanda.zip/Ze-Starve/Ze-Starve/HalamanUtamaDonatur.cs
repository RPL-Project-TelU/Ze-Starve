﻿using System.Windows.Forms;

namespace Ze_Starve
{
    public partial class HalamanUtamaDonatur : Form
    {
        public HalamanUtamaDonatur()
        {
            InitializeComponent();
        }
    }
}
