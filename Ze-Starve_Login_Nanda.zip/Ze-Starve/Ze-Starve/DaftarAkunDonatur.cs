﻿using System.Windows.Forms;

namespace Ze_Starve
{
    public partial class DaftarAkunDonatur : Form
    {
        public DaftarAkunDonatur()
        {
            InitializeComponent();
        }


    }
}
