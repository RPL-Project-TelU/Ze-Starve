﻿using System;
using System.Windows.Forms;

namespace Ze_Starve
{
    public partial class DaftarAkunPenerima : Form
    {
       
        public DaftarAkunPenerima()
        {
            InitializeComponent();
        }

        private void DaftarAkunPenerima_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
