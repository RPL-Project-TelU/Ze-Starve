﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ze_Starve.Models
{
    public class Access_Login
    {
        public int Id { set; get; }
        public string Acc_Login { set; get; }
        public string Error_Description { set; get; }
        public DateTime Expire_Date { set; get; }

        public Access_Login() { }
    }
}
