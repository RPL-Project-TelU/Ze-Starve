﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ze_Starve.Models
{
    public class Cosntants
    {
        public static bool IsDev = true;
    }
}
