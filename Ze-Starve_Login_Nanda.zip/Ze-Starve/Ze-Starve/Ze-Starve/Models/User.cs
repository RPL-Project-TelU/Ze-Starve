﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ze_Starve.Models
{
    public class User
{
        public int Id { set; get; }
        public string Username { set; get; }
        public string Password { set; get; }

        public User() { }
        public User(string Username, string Password)
        {
            this.Username = Username;
            this.Password = Password;
        }
    }

    public bool CheckInformation()
    {
        if (!this.Username.Equals("") && !this.Password.Equals(""))
            return true;
        else
            return false;
    }
}
