﻿
namespace Ze_Starve
{
    partial class DaftarAkun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RbuttonInputFoodshelter = new System.Windows.Forms.RadioButton();
            this.RbuttonInputDonatur = new System.Windows.Forms.RadioButton();
            this.RbuttonInputPenerima = new System.Windows.Forms.RadioButton();
            this.Lbl_Daftar_Sebagai = new System.Windows.Forms.Label();
            this.Btn_Kembali_In_Daftar_Akun = new System.Windows.Forms.Button();
            this.Btn_Selanjutnya_In_Daftar_Akun = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // RbuttonInputFoodshelter
            // 
            this.RbuttonInputFoodshelter.AutoSize = true;
            this.RbuttonInputFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbuttonInputFoodshelter.Location = new System.Drawing.Point(103, 319);
            this.RbuttonInputFoodshelter.Name = "RbuttonInputFoodshelter";
            this.RbuttonInputFoodshelter.Size = new System.Drawing.Size(118, 24);
            this.RbuttonInputFoodshelter.TabIndex = 34;
            this.RbuttonInputFoodshelter.TabStop = true;
            this.RbuttonInputFoodshelter.Text = "Foodshelter";
            this.RbuttonInputFoodshelter.UseVisualStyleBackColor = true;
            // 
            // RbuttonInputDonatur
            // 
            this.RbuttonInputDonatur.AutoSize = true;
            this.RbuttonInputDonatur.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbuttonInputDonatur.Location = new System.Drawing.Point(103, 289);
            this.RbuttonInputDonatur.Name = "RbuttonInputDonatur";
            this.RbuttonInputDonatur.Size = new System.Drawing.Size(90, 24);
            this.RbuttonInputDonatur.TabIndex = 33;
            this.RbuttonInputDonatur.TabStop = true;
            this.RbuttonInputDonatur.Text = "Donatur";
            this.RbuttonInputDonatur.UseVisualStyleBackColor = true;
            // 
            // RbuttonInputPenerima
            // 
            this.RbuttonInputPenerima.AutoSize = true;
            this.RbuttonInputPenerima.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbuttonInputPenerima.Location = new System.Drawing.Point(103, 259);
            this.RbuttonInputPenerima.Name = "RbuttonInputPenerima";
            this.RbuttonInputPenerima.Size = new System.Drawing.Size(101, 24);
            this.RbuttonInputPenerima.TabIndex = 32;
            this.RbuttonInputPenerima.TabStop = true;
            this.RbuttonInputPenerima.Text = "Penerima";
            this.RbuttonInputPenerima.UseVisualStyleBackColor = true;
            // 
            // Lbl_Daftar_Sebagai
            // 
            this.Lbl_Daftar_Sebagai.AutoSize = true;
            this.Lbl_Daftar_Sebagai.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Daftar_Sebagai.Location = new System.Drawing.Point(99, 236);
            this.Lbl_Daftar_Sebagai.Name = "Lbl_Daftar_Sebagai";
            this.Lbl_Daftar_Sebagai.Size = new System.Drawing.Size(121, 20);
            this.Lbl_Daftar_Sebagai.TabIndex = 31;
            this.Lbl_Daftar_Sebagai.Text = "Daftar Sebagai";
            // 
            // Btn_Kembali_In_Daftar_Akun
            // 
            this.Btn_Kembali_In_Daftar_Akun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Kembali_In_Daftar_Akun.Location = new System.Drawing.Point(94, 431);
            this.Btn_Kembali_In_Daftar_Akun.Name = "Btn_Kembali_In_Daftar_Akun";
            this.Btn_Kembali_In_Daftar_Akun.Size = new System.Drawing.Size(134, 36);
            this.Btn_Kembali_In_Daftar_Akun.TabIndex = 28;
            this.Btn_Kembali_In_Daftar_Akun.Text = "Kembali";
            this.Btn_Kembali_In_Daftar_Akun.UseVisualStyleBackColor = true;
            // 
            // Btn_Selanjutnya_In_Daftar_Akun
            // 
            this.Btn_Selanjutnya_In_Daftar_Akun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Selanjutnya_In_Daftar_Akun.Location = new System.Drawing.Point(92, 378);
            this.Btn_Selanjutnya_In_Daftar_Akun.Name = "Btn_Selanjutnya_In_Daftar_Akun";
            this.Btn_Selanjutnya_In_Daftar_Akun.Size = new System.Drawing.Size(136, 36);
            this.Btn_Selanjutnya_In_Daftar_Akun.TabIndex = 27;
            this.Btn_Selanjutnya_In_Daftar_Akun.Text = "Selanjutnya";
            this.Btn_Selanjutnya_In_Daftar_Akun.UseVisualStyleBackColor = true;
            this.Btn_Selanjutnya_In_Daftar_Akun.Click += new System.EventHandler(this.Btn_Selanjutnya_In_Daftar_Akun_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Ze_Starve.Properties.Resources.logoZStarve01;
            this.pictureBox1.Location = new System.Drawing.Point(61, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 201);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // DaftarAkun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 523);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.RbuttonInputFoodshelter);
            this.Controls.Add(this.RbuttonInputDonatur);
            this.Controls.Add(this.RbuttonInputPenerima);
            this.Controls.Add(this.Lbl_Daftar_Sebagai);
            this.Controls.Add(this.Btn_Kembali_In_Daftar_Akun);
            this.Controls.Add(this.Btn_Selanjutnya_In_Daftar_Akun);
            this.Name = "DaftarAkun";
            this.Text = "DaftarAkun";
            this.Load += new System.EventHandler(this.DaftarAkun_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton RbuttonInputFoodshelter;
        private System.Windows.Forms.RadioButton RbuttonInputDonatur;
        private System.Windows.Forms.RadioButton RbuttonInputPenerima;
        private System.Windows.Forms.Label Lbl_Daftar_Sebagai;
        private System.Windows.Forms.Button Btn_Kembali_In_Daftar_Akun;
        private System.Windows.Forms.Button Btn_Selanjutnya_In_Daftar_Akun;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}