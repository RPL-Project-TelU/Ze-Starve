﻿
namespace Ze_Starve
{
    partial class TambahAktivitasFoodshelter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNamaFoodshelter = new System.Windows.Forms.Label();
            this.TxtNamaFoodshelter = new System.Windows.Forms.TextBox();
            this.LblDeskripsiKegiatan = new System.Windows.Forms.Label();
            this.TxtDeskripsiKegiatan = new System.Windows.Forms.TextBox();
            this.LblMenuMakanan = new System.Windows.Forms.Label();
            this.TxtMenuMakanan = new System.Windows.Forms.TextBox();
            this.LblAlamaFoodssheltr = new System.Windows.Forms.Label();
            this.TxtAlamatFoodshelter = new System.Windows.Forms.TextBox();
            this.LblTanggal = new System.Windows.Forms.Label();
            this.DateTanggal = new System.Windows.Forms.DateTimePicker();
            this.LblJumlahPorsi = new System.Windows.Forms.Label();
            this.BtnMulai = new System.Windows.Forms.Button();
            this.BtnBatal = new System.Windows.Forms.Button();
            this.PictureLogoFoodshelter = new System.Windows.Forms.PictureBox();
            this.LinkLogoFoodshelter = new System.Windows.Forms.LinkLabel();
            this.BoxJamMulai = new System.Windows.Forms.ComboBox();
            this.BoxJamSelesai = new System.Windows.Forms.ComboBox();
            this.LblJamMulai = new System.Windows.Forms.Label();
            this.LblJamSelesai = new System.Windows.Forms.Label();
            this.UpDownJumlahPorsi = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.PictureLogoFoodshelter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UpDownJumlahPorsi)).BeginInit();
            this.SuspendLayout();
            // 
            // LblNamaFoodshelter
            // 
            this.LblNamaFoodshelter.AutoSize = true;
            this.LblNamaFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNamaFoodshelter.Location = new System.Drawing.Point(320, 12);
            this.LblNamaFoodshelter.Name = "LblNamaFoodshelter";
            this.LblNamaFoodshelter.Size = new System.Drawing.Size(146, 20);
            this.LblNamaFoodshelter.TabIndex = 20;
            this.LblNamaFoodshelter.Text = "Nama Foodshelter";
            // 
            // TxtNamaFoodshelter
            // 
            this.TxtNamaFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNamaFoodshelter.Location = new System.Drawing.Point(323, 35);
            this.TxtNamaFoodshelter.Name = "TxtNamaFoodshelter";
            this.TxtNamaFoodshelter.Size = new System.Drawing.Size(425, 30);
            this.TxtNamaFoodshelter.TabIndex = 19;
            // 
            // LblDeskripsiKegiatan
            // 
            this.LblDeskripsiKegiatan.AutoSize = true;
            this.LblDeskripsiKegiatan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDeskripsiKegiatan.Location = new System.Drawing.Point(319, 69);
            this.LblDeskripsiKegiatan.Name = "LblDeskripsiKegiatan";
            this.LblDeskripsiKegiatan.Size = new System.Drawing.Size(145, 20);
            this.LblDeskripsiKegiatan.TabIndex = 23;
            this.LblDeskripsiKegiatan.Text = "DeskripsiKegiatan";
            // 
            // TxtDeskripsiKegiatan
            // 
            this.TxtDeskripsiKegiatan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDeskripsiKegiatan.Location = new System.Drawing.Point(323, 92);
            this.TxtDeskripsiKegiatan.Multiline = true;
            this.TxtDeskripsiKegiatan.Name = "TxtDeskripsiKegiatan";
            this.TxtDeskripsiKegiatan.Size = new System.Drawing.Size(425, 87);
            this.TxtDeskripsiKegiatan.TabIndex = 22;
            // 
            // LblMenuMakanan
            // 
            this.LblMenuMakanan.AutoSize = true;
            this.LblMenuMakanan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMenuMakanan.Location = new System.Drawing.Point(320, 184);
            this.LblMenuMakanan.Name = "LblMenuMakanan";
            this.LblMenuMakanan.Size = new System.Drawing.Size(122, 20);
            this.LblMenuMakanan.TabIndex = 25;
            this.LblMenuMakanan.Text = "Menu Makanan";
            // 
            // TxtMenuMakanan
            // 
            this.TxtMenuMakanan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMenuMakanan.Location = new System.Drawing.Point(323, 207);
            this.TxtMenuMakanan.Name = "TxtMenuMakanan";
            this.TxtMenuMakanan.Size = new System.Drawing.Size(425, 30);
            this.TxtMenuMakanan.TabIndex = 24;
            // 
            // LblAlamaFoodssheltr
            // 
            this.LblAlamaFoodssheltr.AutoSize = true;
            this.LblAlamaFoodssheltr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAlamaFoodssheltr.Location = new System.Drawing.Point(320, 242);
            this.LblAlamaFoodssheltr.Name = "LblAlamaFoodssheltr";
            this.LblAlamaFoodssheltr.Size = new System.Drawing.Size(154, 20);
            this.LblAlamaFoodssheltr.TabIndex = 27;
            this.LblAlamaFoodssheltr.Text = "Alamat Foodshelter";
            // 
            // TxtAlamatFoodshelter
            // 
            this.TxtAlamatFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAlamatFoodshelter.Location = new System.Drawing.Point(323, 265);
            this.TxtAlamatFoodshelter.Name = "TxtAlamatFoodshelter";
            this.TxtAlamatFoodshelter.Size = new System.Drawing.Size(425, 30);
            this.TxtAlamatFoodshelter.TabIndex = 26;
            // 
            // LblTanggal
            // 
            this.LblTanggal.AutoSize = true;
            this.LblTanggal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTanggal.Location = new System.Drawing.Point(320, 300);
            this.LblTanggal.Name = "LblTanggal";
            this.LblTanggal.Size = new System.Drawing.Size(68, 20);
            this.LblTanggal.TabIndex = 29;
            this.LblTanggal.Text = "Tanggal";
            // 
            // DateTanggal
            // 
            this.DateTanggal.CustomFormat = "yyyy/MM/dd";
            this.DateTanggal.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DateTanggal.Location = new System.Drawing.Point(324, 323);
            this.DateTanggal.MaxDate = new System.DateTime(2095, 12, 31, 0, 0, 0, 0);
            this.DateTanggal.MinDate = new System.DateTime(1907, 1, 1, 0, 0, 0, 0);
            this.DateTanggal.Name = "DateTanggal";
            this.DateTanggal.Size = new System.Drawing.Size(121, 22);
            this.DateTanggal.TabIndex = 30;
            this.DateTanggal.Value = new System.DateTime(2021, 6, 28, 0, 0, 0, 0);
            // 
            // LblJumlahPorsi
            // 
            this.LblJumlahPorsi.AutoSize = true;
            this.LblJumlahPorsi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblJumlahPorsi.Location = new System.Drawing.Point(489, 300);
            this.LblJumlahPorsi.Name = "LblJumlahPorsi";
            this.LblJumlahPorsi.Size = new System.Drawing.Size(107, 20);
            this.LblJumlahPorsi.TabIndex = 32;
            this.LblJumlahPorsi.Text = "Jumlah Porsi";
            // 
            // BtnMulai
            // 
            this.BtnMulai.Location = new System.Drawing.Point(169, 330);
            this.BtnMulai.Name = "BtnMulai";
            this.BtnMulai.Size = new System.Drawing.Size(95, 30);
            this.BtnMulai.TabIndex = 33;
            this.BtnMulai.Text = "Mulai";
            this.BtnMulai.UseVisualStyleBackColor = true;
            this.BtnMulai.Click += new System.EventHandler(this.BtnMulai_Click);
            // 
            // BtnBatal
            // 
            this.BtnBatal.Location = new System.Drawing.Point(54, 330);
            this.BtnBatal.Name = "BtnBatal";
            this.BtnBatal.Size = new System.Drawing.Size(95, 30);
            this.BtnBatal.TabIndex = 34;
            this.BtnBatal.Text = "Batal";
            this.BtnBatal.UseVisualStyleBackColor = true;
            this.BtnBatal.Click += new System.EventHandler(this.BtnBatal_Click);
            // 
            // PictureLogoFoodshelter
            // 
            this.PictureLogoFoodshelter.Location = new System.Drawing.Point(50, 35);
            this.PictureLogoFoodshelter.Name = "PictureLogoFoodshelter";
            this.PictureLogoFoodshelter.Size = new System.Drawing.Size(216, 216);
            this.PictureLogoFoodshelter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureLogoFoodshelter.TabIndex = 35;
            this.PictureLogoFoodshelter.TabStop = false;
            this.PictureLogoFoodshelter.Click += new System.EventHandler(this.PictureLogoFoodshelter_Click);
            // 
            // LinkLogoFoodshelter
            // 
            this.LinkLogoFoodshelter.AutoSize = true;
            this.LinkLogoFoodshelter.Location = new System.Drawing.Point(53, 271);
            this.LinkLogoFoodshelter.Name = "LinkLogoFoodshelter";
            this.LinkLogoFoodshelter.Size = new System.Drawing.Size(213, 17);
            this.LinkLogoFoodshelter.TabIndex = 36;
            this.LinkLogoFoodshelter.TabStop = true;
            this.LinkLogoFoodshelter.Text = "Unggah Foto / Logo Foodshelter";
            this.LinkLogoFoodshelter.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLogoFoodshelter_LinkClicked);
            // 
            // BoxJamMulai
            // 
            this.BoxJamMulai.FormattingEnabled = true;
            this.BoxJamMulai.Items.AddRange(new object[] {
            "08.00",
            "08.30",
            "09.00",
            "09.30",
            "10.00",
            "10.30",
            "11.00",
            "11.30",
            "12.00",
            "12.30",
            "13.00",
            "13.30",
            "14.00",
            "14.30",
            "15.00",
            "15.30",
            "16.00",
            "16.30",
            "17.00"});
            this.BoxJamMulai.Location = new System.Drawing.Point(324, 375);
            this.BoxJamMulai.Name = "BoxJamMulai";
            this.BoxJamMulai.Size = new System.Drawing.Size(121, 24);
            this.BoxJamMulai.TabIndex = 37;
            // 
            // BoxJamSelesai
            // 
            this.BoxJamSelesai.FormattingEnabled = true;
            this.BoxJamSelesai.Items.AddRange(new object[] {
            "08.00",
            "08.30",
            "09.00",
            "09.30",
            "10.00",
            "10.30",
            "11.00",
            "11.30",
            "12.00",
            "12.30",
            "13.00",
            "13.30",
            "14.00",
            "14.30",
            "15.00",
            "15.30",
            "16.00",
            "16.30",
            "17.00"});
            this.BoxJamSelesai.Location = new System.Drawing.Point(493, 375);
            this.BoxJamSelesai.Name = "BoxJamSelesai";
            this.BoxJamSelesai.Size = new System.Drawing.Size(121, 24);
            this.BoxJamSelesai.TabIndex = 38;
            // 
            // LblJamMulai
            // 
            this.LblJamMulai.AutoSize = true;
            this.LblJamMulai.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblJamMulai.Location = new System.Drawing.Point(320, 352);
            this.LblJamMulai.Name = "LblJamMulai";
            this.LblJamMulai.Size = new System.Drawing.Size(86, 20);
            this.LblJamMulai.TabIndex = 39;
            this.LblJamMulai.Text = "Jam Mulai";
            // 
            // LblJamSelesai
            // 
            this.LblJamSelesai.AutoSize = true;
            this.LblJamSelesai.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblJamSelesai.Location = new System.Drawing.Point(489, 352);
            this.LblJamSelesai.Name = "LblJamSelesai";
            this.LblJamSelesai.Size = new System.Drawing.Size(101, 20);
            this.LblJamSelesai.TabIndex = 40;
            this.LblJamSelesai.Text = "Jam Selesai";
            // 
            // UpDownJumlahPorsi
            // 
            this.UpDownJumlahPorsi.Location = new System.Drawing.Point(493, 323);
            this.UpDownJumlahPorsi.Name = "UpDownJumlahPorsi";
            this.UpDownJumlahPorsi.Size = new System.Drawing.Size(121, 22);
            this.UpDownJumlahPorsi.TabIndex = 31;
            this.UpDownJumlahPorsi.ValueChanged += new System.EventHandler(this.UpDownJumlahPorsi_ValueChanged);
            // 
            // TambahAktivitasFoodshelter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 414);
            this.Controls.Add(this.LblJamSelesai);
            this.Controls.Add(this.LblJamMulai);
            this.Controls.Add(this.BoxJamSelesai);
            this.Controls.Add(this.BoxJamMulai);
            this.Controls.Add(this.LinkLogoFoodshelter);
            this.Controls.Add(this.PictureLogoFoodshelter);
            this.Controls.Add(this.BtnBatal);
            this.Controls.Add(this.BtnMulai);
            this.Controls.Add(this.LblJumlahPorsi);
            this.Controls.Add(this.UpDownJumlahPorsi);
            this.Controls.Add(this.DateTanggal);
            this.Controls.Add(this.LblTanggal);
            this.Controls.Add(this.LblAlamaFoodssheltr);
            this.Controls.Add(this.TxtAlamatFoodshelter);
            this.Controls.Add(this.LblMenuMakanan);
            this.Controls.Add(this.TxtMenuMakanan);
            this.Controls.Add(this.LblDeskripsiKegiatan);
            this.Controls.Add(this.TxtDeskripsiKegiatan);
            this.Controls.Add(this.LblNamaFoodshelter);
            this.Controls.Add(this.TxtNamaFoodshelter);
            this.Name = "TambahAktivitasFoodshelter";
            this.Text = "TambahAktivitasFoodshelter";
            this.Load += new System.EventHandler(this.TambahAktivitasFoodshelter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PictureLogoFoodshelter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UpDownJumlahPorsi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNamaFoodshelter;
        private System.Windows.Forms.TextBox TxtNamaFoodshelter;
        private System.Windows.Forms.Label LblDeskripsiKegiatan;
        private System.Windows.Forms.TextBox TxtDeskripsiKegiatan;
        private System.Windows.Forms.Label LblMenuMakanan;
        private System.Windows.Forms.TextBox TxtMenuMakanan;
        private System.Windows.Forms.Label LblAlamaFoodssheltr;
        private System.Windows.Forms.TextBox TxtAlamatFoodshelter;
        private System.Windows.Forms.Label LblTanggal;
        private System.Windows.Forms.DateTimePicker DateTanggal;
        private System.Windows.Forms.Label LblJumlahPorsi;
        private System.Windows.Forms.Button BtnMulai;
        private System.Windows.Forms.Button BtnBatal;
        private System.Windows.Forms.PictureBox PictureLogoFoodshelter;
        private System.Windows.Forms.LinkLabel LinkLogoFoodshelter;
        private System.Windows.Forms.ComboBox BoxJamMulai;
        private System.Windows.Forms.ComboBox BoxJamSelesai;
        private System.Windows.Forms.Label LblJamMulai;
        private System.Windows.Forms.Label LblJamSelesai;
        private System.Windows.Forms.NumericUpDown UpDownJumlahPorsi;
    }
}