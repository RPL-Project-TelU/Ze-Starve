﻿
namespace Ze_Starve
{
    partial class DaftarAkunFoodshelter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.LinkUnggahFotoLogoFoodshelter = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.BtnKembali = new System.Windows.Forms.Button();
            this.BtnSelesaiDaftarAkun = new System.Windows.Forms.Button();
            this.LinkUnggahFotoKtp = new System.Windows.Forms.LinkLabel();
            this.LinkUnggahFotoBukuTabungan = new System.Windows.Forms.LinkLabel();
            this.linkUnggahLogoFoodshelter = new System.Windows.Forms.LinkLabel();
            this.PictureLogoFoodshelter = new System.Windows.Forms.PictureBox();
            this.LblAlamatFoodshelter = new System.Windows.Forms.Label();
            this.LblNamaFoodshelter = new System.Windows.Forms.Label();
            this.LblNoTelpFoodshelter = new System.Windows.Forms.Label();
            this.LblNoRekeningFoodshelter = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.LblDeskripsiFoodshelter = new System.Windows.Forms.Label();
            this.TxtNamaFoodshelter = new System.Windows.Forms.TextBox();
            this.TxtNoTelpFoodshelter = new System.Windows.Forms.TextBox();
            this.TxtAlamatFoodshelter = new System.Windows.Forms.TextBox();
            this.TxtNoRekeningFoodshelter = new System.Windows.Forms.TextBox();
            this.TxtDeskripsiFoodshelter = new System.Windows.Forms.TextBox();
            this.TxtConfirmPassword = new System.Windows.Forms.TextBox();
            this.LblConfirmPassword = new System.Windows.Forms.Label();
            this.LblPassword = new System.Windows.Forms.Label();
            this.LblUsername = new System.Windows.Forms.Label();
            this.LblNamaBelakang = new System.Windows.Forms.Label();
            this.LblNamaDepan = new System.Windows.Forms.Label();
            this.TxtPassword = new System.Windows.Forms.TextBox();
            this.TxtUsername = new System.Windows.Forms.TextBox();
            this.TxtNamaBelakang = new System.Windows.Forms.TextBox();
            this.TxtNamaDepan = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureLogoFoodshelter)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel1.Controls.Add(this.LinkUnggahFotoLogoFoodshelter);
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Controls.Add(this.BtnKembali);
            this.panel1.Controls.Add(this.BtnSelesaiDaftarAkun);
            this.panel1.Controls.Add(this.LinkUnggahFotoKtp);
            this.panel1.Controls.Add(this.LinkUnggahFotoBukuTabungan);
            this.panel1.Controls.Add(this.linkUnggahLogoFoodshelter);
            this.panel1.Controls.Add(this.PictureLogoFoodshelter);
            this.panel1.Location = new System.Drawing.Point(-1, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(220, 454);
            this.panel1.TabIndex = 26;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // LinkUnggahFotoLogoFoodshelter
            // 
            this.LinkUnggahFotoLogoFoodshelter.AutoSize = true;
            this.LinkUnggahFotoLogoFoodshelter.Location = new System.Drawing.Point(23, 190);
            this.LinkUnggahFotoLogoFoodshelter.Name = "LinkUnggahFotoLogoFoodshelter";
            this.LinkUnggahFotoLogoFoodshelter.Size = new System.Drawing.Size(173, 17);
            this.LinkUnggahFotoLogoFoodshelter.TabIndex = 7;
            this.LinkUnggahFotoLogoFoodshelter.TabStop = true;
            this.LinkUnggahFotoLogoFoodshelter.Text = "Unggah Logo Foodshelter";
            this.LinkUnggahFotoLogoFoodshelter.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkUnggahFotoLogoFoodshelter_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Location = new System.Drawing.Point(0, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(100, 23);
            this.linkLabel1.TabIndex = 0;
            // 
            // BtnKembali
            // 
            this.BtnKembali.Location = new System.Drawing.Point(63, 379);
            this.BtnKembali.Name = "BtnKembali";
            this.BtnKembali.Size = new System.Drawing.Size(93, 30);
            this.BtnKembali.TabIndex = 5;
            this.BtnKembali.Text = "Kembali";
            this.BtnKembali.UseVisualStyleBackColor = true;
            // 
            // BtnSelesaiDaftarAkun
            // 
            this.BtnSelesaiDaftarAkun.Location = new System.Drawing.Point(63, 329);
            this.BtnSelesaiDaftarAkun.Name = "BtnSelesaiDaftarAkun";
            this.BtnSelesaiDaftarAkun.Size = new System.Drawing.Size(93, 30);
            this.BtnSelesaiDaftarAkun.TabIndex = 4;
            this.BtnSelesaiDaftarAkun.Text = "Selesai";
            this.BtnSelesaiDaftarAkun.UseVisualStyleBackColor = true;
            this.BtnSelesaiDaftarAkun.Click += new System.EventHandler(this.BtnSelesaiDaftarAkun_Click);
            // 
            // LinkUnggahFotoKtp
            // 
            this.LinkUnggahFotoKtp.AutoSize = true;
            this.LinkUnggahFotoKtp.Location = new System.Drawing.Point(23, 271);
            this.LinkUnggahFotoKtp.Name = "LinkUnggahFotoKtp";
            this.LinkUnggahFotoKtp.Size = new System.Drawing.Size(121, 17);
            this.LinkUnggahFotoKtp.TabIndex = 3;
            this.LinkUnggahFotoKtp.TabStop = true;
            this.LinkUnggahFotoKtp.Text = "Unggah Foto KTP";
            this.LinkUnggahFotoKtp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkUnggahFotoKtp_LinkClicked);
            // 
            // LinkUnggahFotoBukuTabungan
            // 
            this.LinkUnggahFotoBukuTabungan.AutoSize = true;
            this.LinkUnggahFotoBukuTabungan.Location = new System.Drawing.Point(23, 230);
            this.LinkUnggahFotoBukuTabungan.Name = "LinkUnggahFotoBukuTabungan";
            this.LinkUnggahFotoBukuTabungan.Size = new System.Drawing.Size(195, 17);
            this.LinkUnggahFotoBukuTabungan.TabIndex = 2;
            this.LinkUnggahFotoBukuTabungan.TabStop = true;
            this.LinkUnggahFotoBukuTabungan.Text = "Unggah Foto Buku Tabungan";
            this.LinkUnggahFotoBukuTabungan.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkUnggahFotoBukuTabungan_LinkClicked);
            // 
            // linkUnggahLogoFoodshelter
            // 
            this.linkUnggahLogoFoodshelter.Location = new System.Drawing.Point(0, 0);
            this.linkUnggahLogoFoodshelter.Name = "linkUnggahLogoFoodshelter";
            this.linkUnggahLogoFoodshelter.Size = new System.Drawing.Size(100, 23);
            this.linkUnggahLogoFoodshelter.TabIndex = 6;
            // 
            // PictureLogoFoodshelter
            // 
            this.PictureLogoFoodshelter.Image = global::Ze_Starve.Properties.Resources.Profile;
            this.PictureLogoFoodshelter.Location = new System.Drawing.Point(47, 40);
            this.PictureLogoFoodshelter.Name = "PictureLogoFoodshelter";
            this.PictureLogoFoodshelter.Size = new System.Drawing.Size(130, 130);
            this.PictureLogoFoodshelter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureLogoFoodshelter.TabIndex = 0;
            this.PictureLogoFoodshelter.TabStop = false;
            this.PictureLogoFoodshelter.Click += new System.EventHandler(this.PictureLogoFoodshelter_Click);
            // 
            // LblAlamatFoodshelter
            // 
            this.LblAlamatFoodshelter.AutoSize = true;
            this.LblAlamatFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAlamatFoodshelter.Location = new System.Drawing.Point(528, 160);
            this.LblAlamatFoodshelter.Name = "LblAlamatFoodshelter";
            this.LblAlamatFoodshelter.Size = new System.Drawing.Size(154, 20);
            this.LblAlamatFoodshelter.TabIndex = 30;
            this.LblAlamatFoodshelter.Text = "Alamat Foodshelter";
            // 
            // LblNamaFoodshelter
            // 
            this.LblNamaFoodshelter.AutoSize = true;
            this.LblNamaFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNamaFoodshelter.Location = new System.Drawing.Point(528, 20);
            this.LblNamaFoodshelter.Name = "LblNamaFoodshelter";
            this.LblNamaFoodshelter.Size = new System.Drawing.Size(146, 20);
            this.LblNamaFoodshelter.TabIndex = 27;
            this.LblNamaFoodshelter.Text = "Nama Foodshelter";
            // 
            // LblNoTelpFoodshelter
            // 
            this.LblNoTelpFoodshelter.AutoSize = true;
            this.LblNoTelpFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNoTelpFoodshelter.Location = new System.Drawing.Point(528, 89);
            this.LblNoTelpFoodshelter.Name = "LblNoTelpFoodshelter";
            this.LblNoTelpFoodshelter.Size = new System.Drawing.Size(178, 20);
            this.LblNoTelpFoodshelter.TabIndex = 32;
            this.LblNoTelpFoodshelter.Text = "No Telpon Foodshelter";
            // 
            // LblNoRekeningFoodshelter
            // 
            this.LblNoRekeningFoodshelter.AutoSize = true;
            this.LblNoRekeningFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNoRekeningFoodshelter.Location = new System.Drawing.Point(528, 231);
            this.LblNoRekeningFoodshelter.Name = "LblNoRekeningFoodshelter";
            this.LblNoRekeningFoodshelter.Size = new System.Drawing.Size(197, 20);
            this.LblNoRekeningFoodshelter.TabIndex = 33;
            this.LblNoRekeningFoodshelter.Text = "No Rekening Foodshelter";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(531, 316);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(0, 0);
            this.textBox5.TabIndex = 36;
            // 
            // LblDeskripsiFoodshelter
            // 
            this.LblDeskripsiFoodshelter.AutoSize = true;
            this.LblDeskripsiFoodshelter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDeskripsiFoodshelter.Location = new System.Drawing.Point(528, 306);
            this.LblDeskripsiFoodshelter.Name = "LblDeskripsiFoodshelter";
            this.LblDeskripsiFoodshelter.Size = new System.Drawing.Size(173, 20);
            this.LblDeskripsiFoodshelter.TabIndex = 35;
            this.LblDeskripsiFoodshelter.Text = "Deskripsi Foodshelter";
            // 
            // TxtNamaFoodshelter
            // 
            this.TxtNamaFoodshelter.Location = new System.Drawing.Point(531, 43);
            this.TxtNamaFoodshelter.Multiline = true;
            this.TxtNamaFoodshelter.Name = "TxtNamaFoodshelter";
            this.TxtNamaFoodshelter.Size = new System.Drawing.Size(230, 30);
            this.TxtNamaFoodshelter.TabIndex = 37;
            // 
            // TxtNoTelpFoodshelter
            // 
            this.TxtNoTelpFoodshelter.Location = new System.Drawing.Point(531, 112);
            this.TxtNoTelpFoodshelter.Multiline = true;
            this.TxtNoTelpFoodshelter.Name = "TxtNoTelpFoodshelter";
            this.TxtNoTelpFoodshelter.Size = new System.Drawing.Size(230, 30);
            this.TxtNoTelpFoodshelter.TabIndex = 38;
            // 
            // TxtAlamatFoodshelter
            // 
            this.TxtAlamatFoodshelter.Location = new System.Drawing.Point(531, 183);
            this.TxtAlamatFoodshelter.Multiline = true;
            this.TxtAlamatFoodshelter.Name = "TxtAlamatFoodshelter";
            this.TxtAlamatFoodshelter.Size = new System.Drawing.Size(230, 30);
            this.TxtAlamatFoodshelter.TabIndex = 39;
            // 
            // TxtNoRekeningFoodshelter
            // 
            this.TxtNoRekeningFoodshelter.Location = new System.Drawing.Point(531, 254);
            this.TxtNoRekeningFoodshelter.Multiline = true;
            this.TxtNoRekeningFoodshelter.Name = "TxtNoRekeningFoodshelter";
            this.TxtNoRekeningFoodshelter.Size = new System.Drawing.Size(230, 30);
            this.TxtNoRekeningFoodshelter.TabIndex = 40;
            // 
            // TxtDeskripsiFoodshelter
            // 
            this.TxtDeskripsiFoodshelter.Location = new System.Drawing.Point(532, 329);
            this.TxtDeskripsiFoodshelter.Multiline = true;
            this.TxtDeskripsiFoodshelter.Name = "TxtDeskripsiFoodshelter";
            this.TxtDeskripsiFoodshelter.Size = new System.Drawing.Size(230, 101);
            this.TxtDeskripsiFoodshelter.TabIndex = 41;
            // 
            // TxtConfirmPassword
            // 
            this.TxtConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtConfirmPassword.Location = new System.Drawing.Point(253, 329);
            this.TxtConfirmPassword.Name = "TxtConfirmPassword";
            this.TxtConfirmPassword.Size = new System.Drawing.Size(230, 30);
            this.TxtConfirmPassword.TabIndex = 51;
            // 
            // LblConfirmPassword
            // 
            this.LblConfirmPassword.AutoSize = true;
            this.LblConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblConfirmPassword.Location = new System.Drawing.Point(249, 306);
            this.LblConfirmPassword.Name = "LblConfirmPassword";
            this.LblConfirmPassword.Size = new System.Drawing.Size(147, 20);
            this.LblConfirmPassword.TabIndex = 50;
            this.LblConfirmPassword.Text = "Confirm Password";
            // 
            // LblPassword
            // 
            this.LblPassword.AutoSize = true;
            this.LblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPassword.Location = new System.Drawing.Point(249, 231);
            this.LblPassword.Name = "LblPassword";
            this.LblPassword.Size = new System.Drawing.Size(83, 20);
            this.LblPassword.TabIndex = 49;
            this.LblPassword.Text = "Password";
            // 
            // LblUsername
            // 
            this.LblUsername.AutoSize = true;
            this.LblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblUsername.Location = new System.Drawing.Point(249, 160);
            this.LblUsername.Name = "LblUsername";
            this.LblUsername.Size = new System.Drawing.Size(133, 20);
            this.LblUsername.TabIndex = 48;
            this.LblUsername.Text = "Username/Email";
            // 
            // LblNamaBelakang
            // 
            this.LblNamaBelakang.AutoSize = true;
            this.LblNamaBelakang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNamaBelakang.Location = new System.Drawing.Point(249, 89);
            this.LblNamaBelakang.Name = "LblNamaBelakang";
            this.LblNamaBelakang.Size = new System.Drawing.Size(127, 20);
            this.LblNamaBelakang.TabIndex = 47;
            this.LblNamaBelakang.Text = "Nama Belakang";
            // 
            // LblNamaDepan
            // 
            this.LblNamaDepan.AutoSize = true;
            this.LblNamaDepan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNamaDepan.Location = new System.Drawing.Point(249, 20);
            this.LblNamaDepan.Name = "LblNamaDepan";
            this.LblNamaDepan.Size = new System.Drawing.Size(107, 20);
            this.LblNamaDepan.TabIndex = 46;
            this.LblNamaDepan.Text = "Nama Depan";
            // 
            // TxtPassword
            // 
            this.TxtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPassword.Location = new System.Drawing.Point(253, 254);
            this.TxtPassword.Name = "TxtPassword";
            this.TxtPassword.Size = new System.Drawing.Size(230, 30);
            this.TxtPassword.TabIndex = 45;
            // 
            // TxtUsername
            // 
            this.TxtUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtUsername.Location = new System.Drawing.Point(253, 183);
            this.TxtUsername.Name = "TxtUsername";
            this.TxtUsername.Size = new System.Drawing.Size(230, 30);
            this.TxtUsername.TabIndex = 44;
            // 
            // TxtNamaBelakang
            // 
            this.TxtNamaBelakang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNamaBelakang.Location = new System.Drawing.Point(253, 112);
            this.TxtNamaBelakang.Name = "TxtNamaBelakang";
            this.TxtNamaBelakang.Size = new System.Drawing.Size(230, 30);
            this.TxtNamaBelakang.TabIndex = 43;
            // 
            // TxtNamaDepan
            // 
            this.TxtNamaDepan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNamaDepan.Location = new System.Drawing.Point(253, 43);
            this.TxtNamaDepan.Name = "TxtNamaDepan";
            this.TxtNamaDepan.Size = new System.Drawing.Size(230, 30);
            this.TxtNamaDepan.TabIndex = 42;
            // 
            // DaftarAkunFoodshelter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TxtConfirmPassword);
            this.Controls.Add(this.LblConfirmPassword);
            this.Controls.Add(this.LblPassword);
            this.Controls.Add(this.LblUsername);
            this.Controls.Add(this.LblNamaBelakang);
            this.Controls.Add(this.LblNamaDepan);
            this.Controls.Add(this.TxtPassword);
            this.Controls.Add(this.TxtUsername);
            this.Controls.Add(this.TxtNamaBelakang);
            this.Controls.Add(this.TxtNamaDepan);
            this.Controls.Add(this.TxtDeskripsiFoodshelter);
            this.Controls.Add(this.TxtNoRekeningFoodshelter);
            this.Controls.Add(this.TxtAlamatFoodshelter);
            this.Controls.Add(this.TxtNoTelpFoodshelter);
            this.Controls.Add(this.TxtNamaFoodshelter);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.LblDeskripsiFoodshelter);
            this.Controls.Add(this.LblNoRekeningFoodshelter);
            this.Controls.Add(this.LblNoTelpFoodshelter);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.LblAlamatFoodshelter);
            this.Controls.Add(this.LblNamaFoodshelter);
            this.Name = "DaftarAkunFoodshelter";
            this.Text = "DaftarAkunFoodshelter";
            this.Load += new System.EventHandler(this.DaftarAkunFoodshelter_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureLogoFoodshelter)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkUnggahLogoFoodshelter;
        private System.Windows.Forms.PictureBox PictureLogoFoodshelter;
        private System.Windows.Forms.Label LblAlamatFoodshelter;
        private System.Windows.Forms.Label LblNamaFoodshelter;
        private System.Windows.Forms.Button BtnKembali;
        private System.Windows.Forms.Button BtnSelesaiDaftarAkun;
        private System.Windows.Forms.LinkLabel LinkUnggahFotoKtp;
        private System.Windows.Forms.LinkLabel LinkUnggahFotoBukuTabungan;
        private System.Windows.Forms.Label LblNoTelpFoodshelter;
        private System.Windows.Forms.Label LblNoRekeningFoodshelter;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label LblDeskripsiFoodshelter;
        private System.Windows.Forms.TextBox TxtNamaFoodshelter;
        private System.Windows.Forms.TextBox TxtNoTelpFoodshelter;
        private System.Windows.Forms.TextBox TxtAlamatFoodshelter;
        private System.Windows.Forms.TextBox TxtNoRekeningFoodshelter;
        private System.Windows.Forms.TextBox TxtDeskripsiFoodshelter;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel LinkUnggahFotoLogoFoodshelter;
        private System.Windows.Forms.TextBox TxtConfirmPassword;
        private System.Windows.Forms.Label LblConfirmPassword;
        private System.Windows.Forms.Label LblPassword;
        private System.Windows.Forms.Label LblUsername;
        private System.Windows.Forms.Label LblNamaBelakang;
        private System.Windows.Forms.Label LblNamaDepan;
        private System.Windows.Forms.TextBox TxtPassword;
        private System.Windows.Forms.TextBox TxtUsername;
        private System.Windows.Forms.TextBox TxtNamaBelakang;
        private System.Windows.Forms.TextBox TxtNamaDepan;
    }
}